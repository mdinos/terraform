#!/usr/bin/env bash

export username=woofythedog
export bucket=fake-bucket

pytest ./rs_tracker_lambda_tests.py